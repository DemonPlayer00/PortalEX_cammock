#!/system/bin/sh
# APatch / Magisk 兼容：不改 /vendor，运行时用 overlay 把虚拟 HAL 叠到 HAL 目录上。
# 关键点：overlay 的 upper/work 必须放在 ext4（/cache），/data 在这台机器上不被
# overlayfs 接受（实测 "filesystem ... not supported as upperdir"）。
MODDIR=${0%/*}
HALDIR=/vendor/lib/hw
BASE=/cache/portalex-vcam
UPPER=$BASE/upper
WORK=$BASE/work
LOG=/data/local/tmp/portalex-vcam.log

fail_boot() {
    MSG="$1"
    echo "portalex-vcam: FAILED: $MSG" >> "$LOG"
    echo "PORTALEX_CAMMOCK_BOOT_FAILED: $MSG" > /data/local/tmp/portalex-vcam-error.txt 2>/dev/null || true
    umount "$HALDIR" 2>/dev/null
    exit 1
}

mkdir -p "$UPPER" "$WORK" || fail_boot "cannot create overlay dirs"
[ -s "$MODDIR/system/vendor/lib/hw/camera.msm8998.so" ] || fail_boot "module payload missing"
cp -f "$MODDIR/system/vendor/lib/hw/camera.msm8998.so" "$UPPER/" 2>/dev/null || fail_boot "payload copy failed"
[ -f "$MODDIR/portal.cfg" ] && cp -f "$MODDIR/portal.cfg" "$UPPER/portal.cfg" 2>/dev/null || true
# 真件副本在**挂载前**从 /vendor 现取：不把厂商 blob 放进仓库/模块包。
if [ ! -s "$UPPER/camera.msm8998.orig.so" ]; then
    cp -f /vendor/lib/hw/camera.msm8998.so "$UPPER/camera.msm8998.orig.so" 2>/dev/null || fail_boot "real HAL copy failed"
fi
chcon u:object_r:vendor_file:s0 "$UPPER"/* 2>/dev/null
chcon u:object_r:vendor_file:s0 "$UPPER" "$WORK" 2>/dev/null

# 先补 SELinux：overlay 根目录继承 upper 的 cache_file 标签，HAL 域需要能穿过它。
if [ -x /data/adb/apd ]; then
    /data/adb/apd sepolicy --live "allow hal_camera_default cache_file dir { getattr read open search }" 2>/dev/null
    /data/adb/apd sepolicy --live "allow hal_camera_default cache_file file { read open getattr map execute }" 2>/dev/null
    /data/adb/apd sepolicy --live "allow hal_camera_default vendor_file dir { getattr read open search }" 2>/dev/null
elif [ -x /debug_ramdisk/magiskpolicy ]; then
    /debug_ramdisk/magiskpolicy --live "allow hal_camera_default cache_file dir { getattr read open search }" 2>/dev/null
    /debug_ramdisk/magiskpolicy --live "allow hal_camera_default cache_file file { read open getattr map execute }" 2>/dev/null
    /debug_ramdisk/magiskpolicy --live "allow hal_camera_default vendor_file dir { getattr read open search }" 2>/dev/null
fi

# 不在开机时挂载虚拟 HAL：未启动 cammock 时保留真实相机。
# app 的 start.sh 才会挂载 overlay。
echo "portalex-vcam: ready (not mounted; start cammock to enable)" > /data/local/tmp/portalex-vcam.log
